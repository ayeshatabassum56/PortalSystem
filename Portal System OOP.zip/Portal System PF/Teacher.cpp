#include "Teacher.h"
Teacher::Teacher():person()
{
}
void Teacher::Teacher_info(string id)
{
    string a = id + ".txt";
    ifstream input("C:/Users/92335/Desktop/practise/Project2/Project2/" + id + "/" + a, ios::app);

    while (input >> person::name >> person::id >> Qualification>> person::department >> salary >> person::Email)
    {
        person::Display_info();
        cout <<"Salary : " << this->salary << endl;
        cout <<"Qualification : " << this->Qualification << endl;
        cout <<"Department : " << this->department << endl;
    }
}

void Teacher::attendance_sheet(string idi)
{
   
    string attendance;
    string pass,date;
    cout << "Date: "; cin >> date;
    ifstream input("database.txt", ios::app);
    while (!input.eof())
    {       
        input >> person::name >> person::id >> pass;
        if (input.eof())
        {
            break;
        }
        else
        {
            cout << name << " " << id << " "; cin >> attendance;
            string a = date + "Attendance_sheet.pdf";
            ofstream output("C:/Users/92335/Desktop/practise/Project2/Project2/" + idi + "/" + a, ios::app);
            output << date << person::name << " " << person::id << " " << attendance << endl;
            output.close();

            ofstream output1("C:/Users/92335/Desktop/practise/Project2/Project2/" + id + "/" + "_Attendance sheet.pdf", ios::app);

            output1 << date << " " << person::name << " " << person::id << " " << attendance << endl;
            output1.close();
        }
    }
    input.close();   
}

void Teacher::assign_Quiz()
{
    string Quiz_title,Q_A; int no_of_Question;
    cout << "Quiz Title : "; cin >> Quiz_title;
    ofstream input("C:/Users/92335/Desktop/practise/Project2/Project2/" + id +"/" + Quiz_title + ".txt",ios ::app);
    cout << "No of Question : "; cin >> no_of_Question;
    for(int i=0;i<no_of_Question;i++)
    {
        input << "Question " << i+1<<" ";
        cout << "Question " << i+1<<" ";
        cin.ignore();
        getline(cin, Q_A);
        input << Q_A;
        input << endl;
    }
    ofstream input2("Total_Quiz.pdf", ios::app);
    input2 <<id<< " " << Quiz_title << endl;
    input2.close();
}

void Teacher::uplod_marks()
{
    string Quiz_title, Q_A, idi;
    ifstream input2("Total_Quiz.pdf", ios::app);
    while (!input2.eof())
    {
        input2 >> idi >> Quiz_title;
        if (input2.eof())
        {
            break;
        }
        else
        {            
            cout << Quiz_title << endl;    
        }
    }
    input2.close();
    cout << "Enter quiz to check responses : "; cin >> Quiz_title;
    ifstream input3(Quiz_title+"resonse_id.txt");
    while (!input3.eof())
    {
        input3 >> idi;
        if (input3.eof())
        {
            break;
        }
        else
        {
            cout <<"\t----->" << idi << endl;
        }
    }
    input3.close();
    cout << "Enter response id : "; cin >> idi;

    ifstream input4("C:/Users/92335/Desktop/practise/Project2/Project2/" + idi + "/" + Quiz_title + "Response.txt", ios::app);
    while (getline(input4, Q_A)) 
    { 
        cout <<Q_A << "\n"; 
    }
    input4.close();
    cout << "Grade it : "; cin >> Q_A;
    ofstream input5("C:/Users/92335/Desktop/practise/Project2/Project2/" + idi + "/" + Quiz_title + "_grade.txt", ios::app);
    input5 << Q_A;
    input5.close();
}