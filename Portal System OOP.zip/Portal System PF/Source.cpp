#include"login.h"
int main()
{
	
	login a;
	a.Main();

}
