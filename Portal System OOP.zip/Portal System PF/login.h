#pragma once
#include"SYSTEM.h"
#include<string>
#include<fstream>
#include<iostream>
using namespace std;
class login:public SYSTEM
{
public:
	void Main();
	void registr();              //--> uml fumction
	void log();					 //-->   uml function
	void logn();				       // --> suporting function
	void Student_login();			   // --> suporting function
	void student_login_info();         // --> suporting function
	void Teacher_login_info();         // --> suporting function
	void teacher_login();              // --> suporting function
	void search_T_S();                  // uml

};

