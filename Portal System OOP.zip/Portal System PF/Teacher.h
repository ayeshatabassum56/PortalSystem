#pragma once
#include<iostream>
#include"person.h"
using namespace std;
class Teacher :public person 
{
protected:
	double salary;
	double marks;
	string Qualification;
public:
	Teacher();
	void Teacher_info(string id);// display_teacher_info uml
	void attendance_sheet(string idi);// uml
	void assign_Quiz();
	void uplod_marks();//uml
};

