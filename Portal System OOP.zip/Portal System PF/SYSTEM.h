#pragma once
#include "Teacher.h"
#include"Student.h"
class SYSTEM : public Teacher,public Student
{
public:
	SYSTEM();
	void add_new_student();
	void add_new_teacher();
	void search_teacher();
	void search_student();
};

