#include "Student.h"
#include<fstream>
#include<iostream>
using namespace std;

Student::Student():person()
{
    gpa = 0;
}

Student::Student(string name, string id, string department, string Email,float gpa, string grade, bool Attendance, double fee)
	:person( name,id,department,Email)
{
	this->gpa=gpa;
	this->grade= grade;
	this->Attendance= Attendance;
	this-> semester=semester;
	this->fee=fee;
}

void Student::Student_info(string id)
{
    string a = id + "info.txt";
    ifstream input("C:/Users/92335/Desktop/practise/Project2/Project2/" + id + "/" + a, ios::app);

    while (input >> person::name>>person::id>>semester>>person::department>>person::Email)
    {
        person::Display_info();
        cout <<"Gpa : " << gpa << endl;
        cout <<"Semester : "<< semester << endl;
    }
}

void Student::display_Attendance(string ID)
{
    string attendance,date;
  //  Atandance
        ifstream output("C:/Users/92335/Desktop/practise/Project2/Project2/" + ID + "/" +"_Attendance sheet.pdf");
        while (!output.eof())
        {
            output >> date >> name >> id >> attendance;
            if (output.eof())
            {
                break;
            }
            else
            {
                cout << date << " " << name << " " << id << " " << attendance << endl;
            }
        }
       output.close();
}

void Student::attend_Quiz(string id)
{
    string Quiz_title, Q_A,idi;
    ifstream input2("Total_Quiz.pdf", ios::app);
    while (!input2.eof())
    {
        input2 >> idi >> Quiz_title;
        if (input2.eof())
        {
            break;
        }
        else
        {
            cout << Quiz_title << endl;
        }
    }
    input2.close();
    cout << "Enter Quiz name: ";
    cin >> Quiz_title;
    ifstream input("C:/Users/92335/Desktop/practise/Project2/Project2/" + idi + "/" +Quiz_title + ".txt", ios::app);
    while (getline(input, Q_A))
    {
        cout << Q_A << endl;
        cout<<"sol: ";
       ofstream input3("C:/Users/92335/Desktop/practise/Project2/Project2/" + id + "/" +Quiz_title  +"Response.txt", ios::app);
        cin.ignore();
        getline(cin, Q_A);

        input3 << Q_A << endl;    
    }
    input.close();
    ofstream input4(Quiz_title+"resonse_id.txt", ios::app);
    input4 << id << endl;
    input4.close();
}

void Student::view_grade(string id)
{
    string Quiz_title, Q_A, idi;
    ifstream input2("Total_Quiz.pdf", ios::app);
    while (!input2.eof())
    {
        input2 >> idi >> Quiz_title;
        if (input2.eof())
        {
            break;
        }
        else
        {
            cout << Quiz_title << endl;
        }
    }
    input2.close();
    cout << "Enter QUIZ_Title : "; cin >> Quiz_title;
    ifstream input5("C:/Users/92335/Desktop/practise/Project2/Project2/" + person::id + "/" + Quiz_title + "_grade.txt");
    input5 >> Q_A;
    cout <<"Your obtain Marks:  " << Q_A << endl;
    input5.close();
}
