#pragma once
#include"person.h"
class Student :public person
{
protected:
	float gpa;
	string grade;
	bool Attendance;
	int semester;
	double fee;
public:
	Student();
	Student(string name, string id, string department, string Email,float gpa, string grade, bool Attendance, double fee);
     void Student_info(string user);
	 void display_Attendance(string ID);
	 void attend_Quiz(string id);
	 void view_grade(string id);
};

