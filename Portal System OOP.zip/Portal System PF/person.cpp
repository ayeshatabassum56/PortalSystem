#include "person.h"
#include<iostream>
using namespace std;

person::person()
{
	
}

person::person(string name, string id, string department, string Email)
{
	this->name=name;
	this->id=id;
	this->department=department;
	this->Email=Email;
}

void person::Display_info()
{
	cout <<"Name: " << this->name << endl;
	cout <<"ID : " << this->id << endl;
	cout <<"Department: " << this->department << endl;
	cout <<"Email: "<< this->Email << endl;
}

