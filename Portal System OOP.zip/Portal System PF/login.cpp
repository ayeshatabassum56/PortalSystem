#include "login.h"
void login::Main()
{
    int choice;
    cout << "***********************************************************************\n\n\n";
    cout << "                      Welcome to login page                               \n\n";
    cout << "*******************        MENU        *******************************\n\n";
    cout << "1.LOGIN" << endl;
    cout << "2.REGISTER" << endl;
    cout << "3.Search " << endl;
    cout << "4.Exit" << endl;
    cout << "\nEnter your choice :";
    cin >> choice;
    cout << endl;
    switch (choice)
    {
    case 1:
        
        logn();
        break;
    case 2:

        registr();
        break;
    case 3:
        search_T_S();
        break;
    case 4:
        cout << "Thanks for using this program.";
        break;
    default:
        system("cls");
        cout << "You've made a mistake , Try again..\n" << endl;
        Main();
    }
}

void login::registr()
{
    system("cls");
    int choice;
    cout << "***********************************************************************\n\n\n";
    cout << "                      Welcome to Admin page                               \n\n";
    cout << "*******************        MENU        *******************************\n\n";
    cout << "1.ADD Student" << endl;
    cout << "2.ADD Teacher" << endl;
    cout << "4.Exit" << endl;
    cout << "\nEnter your choice :";
    cin >> choice;
    cout << endl;
    switch (choice)
    {
    case 1:
        SYSTEM::add_new_student();
        break;
    case 2:
        //registr();
        SYSTEM::add_new_teacher();
        break;
    case 3:

        cout << "selected option is Invalid ";
        break;
    default:
        system("cls");
        cout << "You've made a mistake , Try again..\n" << endl;
        Main();
    }
}

void login::log()
{
    string user, pass, u, p,id;
    int hold=0;
    
    system("cls");
    cout << "please enter the following details" << endl;
    cout << "User Name :";
    cin >> user;
    cout << "Password :";
    cin >> pass;

    ifstream input("database.txt");
    while (!input.eof())
    {
        input >> u >> id>>p;
        if (u == user && p == pass)//match 
        {
            hold = 1;
            system("cls");
            break;
        }   
    }
    input.close();
    if (hold == 1)
    {
        logn();
    }
    else
    {
        cout << "\nLOGIN ERROR\nPlease check your username and password\n";
       /// main();
    }
}

void login:: logn()
{
    system("cls");
    int choice;
    cout << "***********************************************************************\n\n\n";
    cout << "                      Welcome to login page                               \n\n";
    cout << "*******************        MENU        *******************************\n\n";
    cout << "1. Student Login ";
    cout << "2. Teacher Login ";
    cout << "\nEnter your choice ";
    cin >> choice;
    if (choice == 1)
    {
        Student_login();
    }
    else if(choice==2)
    {
        teacher_login();
    }
}

void login::Student_login()
{
    string user, pass, u, p;
    int hold = 0;
    system("cls");
    cout << "please enter the following details" << endl;
    cout << "User Name :";
    cin >> user;
    cout << "Password :";
    cin >> pass;
    ifstream input("database.txt");
    while (!input.eof())
    {
        input >> u >> person::id >> p;
        if (u == user && p == pass)
        {
            hold = 1;
            system("cls");
            break;
        }
    }
    input.close();
    if (hold == 1)
    {
        student_login_info();
    }
    else
    {
        cout << "\nLOGIN ERROR\nPlease check your username and password\n";
        /// main();
    }
}

void login::student_login_info()
{
    system("cls");
    int choice; string hold;
    cout << "***********************************************************************\n\n\n";
    cout << "                      Welcome to login page                               \n\n";
    cout << "*******************        MENU        *******************************\n\n";
    cout << "1. student info " << endl;
    cout << "2. Attandance  " << endl;
    cout << "3. Quizes  " << endl;
    cout << "4. Marks " << endl;
    cout << "5.Exit" << endl;
    cout << "\nEnter your choice ";
    cin >> choice;
    if (choice == 1)
    {
        Student::Student_info(person::id);
        cout << "Enter any key for hold"; cin >> hold;
        student_login_info();
    }
    else if (choice == 2)
    {
        Student::display_Attendance(person::id);
        cout << "Enter any key for hold"; cin >> hold;
        student_login_info();
    }
    else if (choice == 3)
    {
        Student::attend_Quiz(person::id);
        cout << "Enter any key for Exit"; cin >> hold;
        student_login_info();
    }
    else if (choice == 4)
    {
        Student::view_grade(person::id);
        cout << "Enter any key for Exit"; cin >> hold;
        student_login_info();
    }
    else if (choice == 5)
    {
        system("cls");
        Main();
    }
    else
    {
        cout << "Invalid choice ";
    }
}

void login::Teacher_login_info()
{
    system("cls");
    int choice; string hold;
    cout << "***********************************************************************\n\n\n";
    cout << "                      Welcome to login page                               \n\n";
    cout << "*******************        MENU        *******************************\n\n";
    cout << "1. Teacher info " << endl;
    cout << "2. Attandance  " << endl;
    cout << "3. Quizes  " << endl;
    cout << "4. Quize_Response and Marks  " << endl;
    cout << "\nEnter your choice ";
    cin >> choice;
    if (choice == 1)
    {
        Teacher::Teacher_info(person::id);
        cout << "Enter any key for hold"; cin >> hold;
        Teacher_login_info();
    }
    else if (choice == 2)
    {
        Teacher::attendance_sheet(person::id);
        cout << "Enter any key for hold"; cin >> hold;
        Teacher_login_info();
    }
    else if (choice == 3)
    {
        Teacher::assign_Quiz();
        cout << "Enter any key for Exit"; cin >> hold;
        Teacher_login_info();
    }
    else if (choice == 4)
    {
        uplod_marks();
        cout << "Enter any key for Exit"; cin >> hold;
        Teacher_login_info();
    }
    else
    {
        cout << "Wrong choice ";
    }
}

void login::teacher_login()
{
    string user, pass, u, p;
    int hold = 0;

    system("cls");
    cout << "please enter the following details" << endl;
    cout << "User Name :";
    cin >> user;
    cout << "Password :";
    cin >> pass;

    ifstream input("T_database.txt");
    while (!input.eof())
    {
        input >> u >> person::id >> p;
        if (u == user && p == pass)

        {
            hold = 1;
            system("cls");
            break;
        }
    }
    input.close();
    if (hold == 1)
    {
        Teacher_login_info();
    }
    else
    {
        cout << "\nLOGIN ERROR\nPlease check your username and password\n";
    }
}

void login::search_T_S()
{
    system("cls");
    int choice;
    cout << "***********************************************************************\n\n\n";
    cout << "                      Welcome to Search page                               \n\n";
    cout << "*******************        MENU        *******************************\n\n";
    cout << "1.Search Teacher" << endl;
    cout << "2.Search Student" << endl;
    cout << "3.Exit" << endl;
    
    cout << "\nEnter your choice :";
    cin >> choice;
    cout << endl;
    if (choice == 1)
    {
        SYSTEM::search_teacher();
    }
    else if (choice == 2)
    {
        SYSTEM::search_student();
    }
    else if(choice==3)
    {
        Main();
    }

}
