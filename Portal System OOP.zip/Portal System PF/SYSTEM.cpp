#include "SYSTEM.h"
#include<string>
#include<fstream>
#include<iostream>
using namespace std;
SYSTEM::SYSTEM():Teacher(),Student()
{
}
void SYSTEM::add_new_student()
{
    //<---------------------get info------------------------->
    system("cls");
    cout << "Enter New student :";
    cin >> person::name;
    cout << "Enter ID ";
    cin >> person::id;

    cout << "Semester ";
    cin >> Student::semester;

    cout << "Enter Department: ";
    cin >> person::department;

    //<---------------------creating folder of student ------------------------>
    system(("mkdir " +person::id).c_str());///
     
   //--------------creating of file------------//
    string a = person::id + "info.txt";

    ofstream reg("C:/Users/92335/Desktop/practise/Project2/Project2/" + person::id + "/" + a, ios::app);
    string email = person::id + "@ucp.edu.pk";

    reg <<person::name<<" ";
    reg <<person::id << " ";
    reg << Student::semester << " ";
    reg <<person::department <<" ";
    reg << email << " ";
    reg.close();

    //--------> storing in database----------->>
    string password="ucp"+person::id;
    ofstream input1("database.txt",ios::app);
    input1 << person::name<<" ";
    input1 << person::id<<" ";
    input1 << password<<endl;
    input1.close();
    // system("cls");
    cout << "\nRegistration Sucessful\n";
}

void SYSTEM::add_new_teacher()
{
    system("cls");
    cout << "Enter New teacher :";
    cin >> person::name;
    cout << "Enter ID ";
    cin >> person::id;

    cout << "Qualification: ";
    cin >> Teacher::Qualification;

    cout << "Enter Department: ";
    cin >> person::department;

    cout << "Enter Salary : ";
    cin >> Teacher::salary;

    //<---------------------creating folder of student ------------------------>
    system(("mkdir " + person::id).c_str());

    //--------------creating of file------------//
    string a = person::id + ".txt";
    string email = person::name + "@ucp.edu.pk";

    ofstream reg("C:/Users/92335/Desktop/practise/Project2/Project2/" + person::id + "/" + a, ios::app);
    reg << person::name << " ";
    reg << person::id << " ";
    reg << Teacher::Qualification<< " ";
    reg << person::department << " ";
    reg << Teacher::salary << " ";
    reg << email << " ";
    reg.close();

    //--------> storing in database----------->>
    string password = "ucp" + person::id;
    ofstream input("T_database.txt", ios::app);
    input << person::name << " ";
    input << person::id << " ";
    input << password << endl;
    // system("cls");
    cout << "\nRegistration Sucessful\n";
}

void SYSTEM::search_teacher()
{
    string SRCH_teacher,pass,id;
    ifstream input1("T_database.txt", ios::app);
    cout << "Enter id to search teacher : "; cin >> id;
    while (!input1.eof())
    {
        input1 >> person::name>>SRCH_teacher>>pass;
        if (input1.eof())
        {
            break;
        }
        else
        {
            if (id == SRCH_teacher)
            {
                cout << person::name << " " << id;
            }
            
        }
    }
    input1.close();
}

void SYSTEM::search_student()
{
    string SRCH_teacher, pass, id;
    ifstream input1("database.txt", ios::app);
    cout << "Enter id to search teacher: "; cin >> id;
    while (!input1.eof())
    {
        input1 >> person::name >> SRCH_teacher >> pass;
        if (input1.eof())
        {
            break;
        }
        else
        {
            if (id == SRCH_teacher)
            {
                cout << person::name << " " << id;
            }
            
        }
    }
    input1.close();
}
