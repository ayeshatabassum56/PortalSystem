#pragma once
#include<string>
#include<fstream>
#include<iostream>
using namespace std;
class person
{
protected:
	string name;
	string id;
	string department;
	string Email;
public:
	    person();
		person(string name, string id, string department, string Email);
		void Display_info();  
};

